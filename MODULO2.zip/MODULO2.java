/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.al100;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 50497
 */
public class MODULO2 {
    
    public String mensajePOO() {
        return "Programación Orientada a Objetos 2021";
    }

   
    public String mensajeEdad(int edad) {
        if (edad >= 21) {
            return "Mayor de edad";
        } else {
            return "Menor de edad";
        }
    }

    
    public int multiplicacion(int a, int b) {
        return a * b;
    }

    
    public List<Integer> numerosHastaX(int x) {
        List<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= x; i++) {
            numeros.add(i);
        }
        return numeros;
    }
}



